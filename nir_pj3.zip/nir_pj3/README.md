# 主要环境

python>=3.6

pytorch==1.6.0

# 运行步骤

## 第一步：生成数据

下载百度网盘数据并解压（有更新）：链接：https://pan.baidu.com/s/1LMQvf6y9UKEJ1kv7Fkv83w 提取码：udyb

进入 data_loader.py，修改第100行的 `root_dir` 路径为之前解压的路径；

在第193和194行有示例，选择适合的波形；

需要检测异常波形的同学，请在第57和58行之前进行判断，如果是异常波形则不用append当前波形数据；

~~需要选择不同输入（光强度、反射率、吸收率及其组合）的同学，请修改第31行 `_load_org` 函数；~~
选择不同输入（光强度、反射率、吸收率及其组合）请第212-215行的feat_mask

然后，运行 `python data_loader3.py`，将在 `data/raw` 文件下下生成 `NIR_xxx` 的文件夹，
同时屏幕将打印出 `NIR_xxx` 的对应名称。

## 第二步：运行模型

运行 `python train.py --dataset NIR_xxx --gpu_id 0`

其中 `NIR_xxx` 为之前生成的对应数据集的名称；

`--kernels 1,1,1` 中的横向维度的卷积核大小，不大于输入数据的维度数（当前模型的维度为5，一个原始特征，一个归一化特征，三个平滑特征），涉及到任务2和任务3的同学需要尝试不同的横向维度卷积核；

最后，运行结果请统计出最后的 `test_acc` / `best acc possible` / `best mae possible` 值并按模板记录。

## 第三步：记录结果值

使用Word文档记录，这次工作比较灵活，没有模板。

本次运行结果的baseline为：

```
python dist_train.py --dataset NIR_dist_linen_cotton_1350_1650 --kernels 1,1,1 (batch_first=True)
Epoch: 1134 loss_train: 0.68470192 acc_train: 0.7446 mae_train: 0.0397 loss_val: 1.5798 acc_val: 0.4843 mae_val: 0.0787 time: 0.4019s
test_acc: 0.48430962343096234
best possible: 0.4874476987447699
Optimization Finished!
Total time elapsed: 445.5735s
NIR_dist_linen_cotton_1350_1650 Test set results: loss= 1.5919 mae= 0.0792 accuracy= 0.4854
```

# 任务分工

## 任务1：超参调整

1. 丁玫菲：超参调整，train.py里面的lr/dropout, dist_model.py里面第29行的batch_first参数（取TRUE和FALSE的效果差别）
2. 孙鹏磊：波长范围
3. 徐皓东：超参调整，train.py里面的filters/layers/kernels

## 任务2：模型调整

1. 陈挺：继续寻找模型可以更改的地方，可以按照常规使用LSTM和CNN的结构进行修改
2. 臧璇、刘香君：调整dist_models.py第28~70行的模型结构代码，包括里面打上TODO注释的所有点
3. 丁盛：dist_train.py的第155行的优化器可以试试更多
4. 张博涵：在data_loader3.py第224和226行设置不同的扩充策略进行对比
5. 陶赟：针对类不平衡问题，参考focal loss等方法对objective function进行改进

## 任务3：unmixing接入

1. 刘维平、陶赟：请刘维平主导，以陶赟的differential unmixing结合TapNet的工作为基础，跑通本项目和陶赟的工作，总结其效果和可能的优化点（这块有问题可以和陶赟多交流讨论）；