#coding=utf-8
import os
import csv
import random
import numpy as np
import scipy.signal as signal
from scipy.fftpack import fft,ifft
from openpyxl import load_workbook

def get_fft(data):
    #对强度信号进行傅里叶变换
    s=fft(data)
    #为了滤除高频噪声信号，采用截断函数可以做到这一点
    #根据傅里叶变换的结果设置合适的截断函数
    m=len(s)
    n=50
    cutfun=np.ones([m,1])
    cutfun[20:m-20]=0
    ss =s
    ss[n:m-n]=0 #对傅里叶变换信号做截断
    f=ifft(ss) #逆傅里叶变换
    real_f=np.real(f)
    return real_f

def apply_norm(inp_ys):
    cys = np.array(inp_ys)
    rys = []
    for i in range(cys.shape[-1]):
        ys = cys[:, i]
        maxv, minv = max(ys), min(ys)
        nys = []
        for y in ys:
            nys.append((y - minv) / (maxv - minv))
        rys.append(nys)
    return list(np.array(rys).T)

def _load_csv(csv_path):
    xs, ys = [], []
    with open(csv_path, 'r', encoding='utf8') as fo:
        reader = csv.reader(fo)
        lid = 0
        for row in reader:
            if lid < 35 and (row[0] == '' or row[0][0] != '9'):
                lid += 1
                continue
            else:
                xs.append(float(row[0]))
            ys.append(float(row[1]))
            lid += 1
    return xs, ys

def _load_org(dirs, labels, feat_mask=[1,2]):
    xseries, yseries, zseries = [], [], []
    index_dict = {}
    idx = 0
    for d in dirs:
        if os.path.isfile(d):
            continue
        if int(d.split('/')[-1]) not in labels:
            continue
        cur_label = labels[int(d.split('/')[-1])]
        files = os.listdir(d)
        fnames = []
        for f in files:
            if f[-6:] == '_r.csv':
                fnames.append(f[:-6])
        tx, ty, tz = [], [], []
        for fname in fnames:
            refl_name = d + '/' + fname + '_r.csv'
            absb_name = d + '/' + fname + '_a.csv'
            ints_name = d + '/' + fname + '_i.csv'
            xs, rys = _load_csv(refl_name)
            _, ays = _load_csv(absb_name)
            _, iys = _load_csv(ints_name)
            tx.append(xs)
            ty.append([[iy, ay, ry] for ry, ay, iy in zip(rys, ays, iys)])
            tz.append(cur_label)
            index_dict[idx] = d
            idx += 1
        xseries += tx
        yseries += ty
        zseries += tz
    return np.array(xseries), np.array(yseries)[:, :, feat_mask], np.array(zseries), index_dict

def _load_np(xarr, yarr, zarr, min_wave, max_wave, norm=True):
    series, labels = [], []
    for tx, ty, tz in zip(xarr, yarr, zarr):
        tmp_sery = []
        for xs, ys in zip(tx, ty):
            if xs >= min_wave and xs < max_wave:
                tmp_sery.append(ys)
        # tmp_sery = preprocess(tmp_sery) # 调用预处理方法，也可以直接调用某个指定的，以便传入参数
        if norm:        # TODO: 这个norm也可以尝试加上和不加的对比
            tmp_sery = apply_norm(tmp_sery)
        series.append(tmp_sery)
        labels.append(tz)
    return np.array(series), np.array(labels)
        
class DataLoader:
    def __init__(self, dir_path, labels, slices=False, norm=True, feat_mask=[1,2]):
        if dir_path[-1] != '/':
            dir_path += '/'
        dirs = [dir_path + lc for lc in os.listdir(dir_path)]
        self.norm = norm
        self.slices = slices
        self.orgx, self.orgy, self.orgz, self.idx_dic = _load_org(dirs, labels, feat_mask=feat_mask)

    def get_patch(self, minx, maxx):
        if not self.slices:
            return _load_np(self.orgx, self.orgy, self.orgz, minx, maxx, norm=self.norm)
        patches, pls = [], []
        for xs, ys, zs in zip(self.orgx, self.orgy, self.orgz):
            series, labels = _load_np(xs, ys, zs, minx, maxx, norm=self.norm)
            patches.append(series)
            pls.append(labels)
        patches, pls = np.array(patches), np.array(pls)
        print(patches.shape, pls.shape, '///')
        return patches, pls

def load_xlsx(label_path):
    workbook = load_workbook(label_path)
    sheets = workbook.sheetnames
    labels = {}
    for sheet in sheets:
        if sheet not in labels:
            labels[sheet] = {}
        sdata = workbook[sheet]
        rows, cols = sdata.max_row, sdata.max_column
        for i in range(rows):
            cid = sdata.cell(row=i+1, column=1).value
            comps = []
            for j in range(1, cols):
                val = int(sdata.cell(row=i+1, column=j+1).value) / 100
                comps.append(val)
            if cid not in labels[sheet]:
                labels[sheet][cid] = comps
    return labels


def load_multivariate_dist(root_dir='../data/puyan/', minx=890, maxx=1710, mixes=['linen', 'cotton', 'linen_cotton'], device='A', feat_mask=[1,2], num_types=6):
    all_labels = load_xlsx(root_dir + 'labels.xlsx')
    train_dirs = root_dir + device + '/'
    test_dirs = root_dir + device + '2/'
    cnts = {}
    for ctrain in os.listdir(train_dirs):
        if ctrain not in cnts:
            cnts[ctrain] = 0
        cnts[ctrain] += len(os.listdir(train_dirs + ctrain))

    for ctest in os.listdir(test_dirs):
        if ctest not in cnts:
            cnts[ctest] = 0
        cnts[ctest] += len(os.listdir(test_dirs + ctest))
    cnames = cnts.keys()
    
    train_x, train_y, test_x, test_y = [], [], [], []
    num_feat = len(feat_mask)
    for cname in cnames:
        if cname not in mixes:
            continue
        if '_' in cname:
            labels = all_labels[cname]
        elif cname == mixes[0]:
            labels = {}
            for i in range(1000):
                labels[i] = [1.0, 0]
        else:
            labels = {}
            for i in range(1000):
                labels[i] = [0, 1.0]
        train_loader = DataLoader(train_dirs + cname, labels, norm=False)
        cur_trainx, train_cury = train_loader.get_patch(minx, maxx)
        train_loader_norm = DataLoader(train_dirs + cname, labels)
        cur_trainx_norm, _ = train_loader_norm.get_patch(minx, maxx)
        for org, norm, cury in zip(cur_trainx, cur_trainx_norm, train_cury):
            cur_patch = []
            norg = np.array(org)
            dsav = list(np.array([signal.savgol_filter(norg[:, i], 5, 3) for i in range(num_feat)]).T)
            dfft = list(np.array([get_fft(norg[:, i]) for i in range(num_feat)]).T)
            dwie = list(np.array([signal.wiener(norg[:, i]) for i in range(num_feat)]).T)
            for o, n, s, f, w in zip(org, norm, dsav, dfft, dwie):
                cur_patch.append(list(o) + list(n) + list(s) + list(f) + list(w))
            train_x.append(cur_patch)
        train_y += list(train_cury)

        test_loader = DataLoader(test_dirs + cname, labels, norm=False)
        cur_testx, test_cury = test_loader.get_patch(minx, maxx)
        print(cur_testx.shape, test_cury.shape, '//')
        test_loader_norm = DataLoader(test_dirs + cname, labels)
        cur_testx_norm, _ = test_loader_norm.get_patch(minx, maxx)
        for org, norm in zip(cur_testx, cur_testx_norm):
            cur_patch = []
            norg = np.array(org)
            dsav = list(np.array([signal.savgol_filter(norg[:, i], 5, 3) for i in range(num_feat)]).T)
            dfft = list(np.array([get_fft(norg[:, i]) for i in range(num_feat)]).T)
            dwie = list(np.array([signal.wiener(norg[:, i]) for i in range(num_feat)]).T)
            for o, n, s, f, w in zip(org, norm, dsav, dfft, dwie):
                cur_patch.append(list(o) + list(n) + list(s) + list(f) + list(w))
            test_x.append(cur_patch)
        test_y += list(test_cury)
    train_dy = dist_labels(train_y, mixes, num_types=num_types)
    test_dy = dist_labels(test_y, mixes, num_types=num_types)
    train_x, train_dy, train_y = augment(train_x, train_dy, train_y, num_types=num_types)
    return np.array(train_x), np.array(train_dy), np.array(test_x), np.array(test_dy), np.array(train_y)[:, 0], np.array(test_y)[:, 0]

def save_multi_dist(minx=890, maxx=1710, mixes=['linen', 'cotton', 'linen_cotton'], device='A', num_types=6):
    xtrain, ytrain, xtest, ytest, fytrain, fytest = load_multivariate_dist(minx=minx, maxx=maxx, mixes=mixes, device=device, num_types=num_types)
    print(xtrain.shape, ytrain.shape)
    save_path = 'data/NIR_dist_' + '+'.join(mixes) + '_' + str(minx) + '_' + str(maxx) + '/'
    print(save_path)
    if not os.path.exists(save_path):
        os.mkdir(save_path)
    np.save(save_path + 'X_train.npy', xtrain.transpose(0, 2, 1))
    np.save(save_path + 'y_train.npy', ytrain[:, np.newaxis])
    np.save(save_path + 'X_test.npy', xtest.transpose(0, 2, 1))
    np.save(save_path + 'y_test.npy', ytest[:, np.newaxis])
    np.save(save_path + 'fy_train.npy', fytrain)
    np.save(save_path + 'fy_test.npy', fytest)
    print(xtrain.shape, ytrain.shape, xtest.shape, ytest.shape, fytrain.shape, fytest.shape)

def augment(xs, ys, fys, num_types=6):
    nxs, nys, nfs = [], [], []
    if num_types == 3:
        aug_times = [3, 1, 3]
    else:
        aug_times = [12, 8, 6, 4, 1, 3]
    for x, y, f in zip(xs, ys, fys):
        aug_time = aug_times[y]
        for _ in range(aug_time):
            nxs.append(x)
            nys.append(y)
            nfs.append(f)
    return nxs, nys, nfs

def dist_labels(ys, mixes, num_types=6):
    '''
        三类：
        A       0.46-0.56       232+2+34     268
        B/C/D   0.02-0.4        31+16+24     71
        E       0.57-0.95       8+67         75

        六类：
        0.55                                    232                     232         5       0.55
        0.6, 0.63, 0.57, 0.58                   59, 2, 1, 5             67          6       0.6
        0.3, 0.33, 0.34, 0.32, 0.28, 0.27       25, 2, 1, 1, 1, 1       31          3       0.3
        0.15, 0.1, 0.11                         11, 3, 2                16          1       0.15
        0.5, 0.51, 0.49, 0.48, 0.46, 0.4, 0.52  10, 2, 2, 1, 1, 3, 34   53          4       0.52
        0.2, 0.21, 0.22, 0.25, 0.23             8, 2, 1, 10, 3          24          2       0.25
        0.7, 0.65, 0.66, 0.8, 0.75              3, 2, 1, 1, 1           8           6       0.6
    '''
    if (len(mixes) == 3 and 'linen' in mixes and 'cotton' in mixes and 'linen_cotton'in mixes) or  \
        (len(mixes) == 1 and mixes[0] == 'linen_cotton'):
        nys = []
        if num_types == 6:
            for y in ys:
                if y[0] == 0.55:
                    nys.append(4)
                # elif y[0] == 0:
                #     nys.append(0)
                # elif y[0] == 1:
                #     nys.append(7)
                elif y[0] <= 0.15 and y[0] >= 0.1:
                    nys.append(0)
                elif y[0] <= 0.25 and y[0] >= 0.2:
                    nys.append(1)
                elif y[0] <= 0.34 and y[0] >= 0.27:
                    nys.append(2)
                elif y[0] <= 0.52 and y[0] >= 0.4:
                    nys.append(3)
                elif y[0] <= 0.8 and y[0] >= 0.57:
                    nys.append(5)
                else:
                    print('!!!', y[0])
        elif num_types == 3:
            for y in ys:
                if y[0] <= 0.4 and y[0] >= 0.02:
                    nys.append(0)
                elif y[0] <= 0.56 and y[0] >= 0.46:
                    nys.append(1)
                elif y[0] <= 0.9 and y[0] >= 0.57:
                    nys.append(2)
                else:
                    print('!!!', y[0])
        return nys
    return ys
    
if __name__ == '__main__':
    # TODO: num_type这里表示设置刻度点的数量，这里支持6和3，具体划分
    save_multi_dist(1100, 1650, ['linen_cotton'], device='A', num_types=6)

'''
python dist_train.py --dataset NIR_dist_linen_cotton_1350_1650 --kernels 1,1,1 (batch_first=True)
Epoch: 1134 loss_train: 0.68470192 acc_train: 0.7446 mae_train: 0.0397 loss_val: 1.5798 acc_val: 0.4843 mae_val: 0.0787 time: 0.4019s
test_acc: 0.48430962343096234
best possible: 0.4874476987447699
Optimization Finished!
Total time elapsed: 445.5735s
NIR_dist_linen_cotton_1350_1650 Test set results: loss= 1.5919 mae= 0.0792 accuracy= 0.4854
'''